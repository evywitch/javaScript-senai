let frutas = ["Banana", "Uva"]

frutas.forEach(function(frutas) { 
    console.log(``)
})