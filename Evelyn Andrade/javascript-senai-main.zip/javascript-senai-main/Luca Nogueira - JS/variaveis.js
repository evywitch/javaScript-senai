// let nome = "Luca" - pode-se declarar a variavel normalmente
// nome = "Angela" - com o let, a variavel é mutavel, porme indeclaravel mais de uma vez
// let nome = "Oi" - é mutavel, pode-se mudar o valor 

// tipos de variaveis em js: let, var ou const 

// VAR: variavel mutavel, ou seja, pode-se mudar ao longo do codigo 
// LET: com let não é possivel redeclarar uma variavel, ou seja, criar novamnente a varivel, porem, é mutavel.
// CONST: obviamente, é uma varaivel IMUTAVEL ao longo do codigo, nao pode-se mudar.