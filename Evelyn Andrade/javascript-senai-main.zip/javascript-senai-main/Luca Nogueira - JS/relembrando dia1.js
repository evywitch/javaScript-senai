// relembrar estrutura de dados, criação de variaveis etc. 

let nome = "Luca" // str

let pi = 3.14159265359 // int 

const vivo = true //valor boolean

let frutas = ["Maça", "Banana", "Uva", "Laranja"] // array

let aluno = { // objetos
    Nome: "Luca",
    Idade: 16,
    Inscrito: "JavaSript",
    Unidade: "SENAI Suiço-Brasileira",
    Local: "Santo Amaro"
}

console.log(frutas[0])

console.log(`o(a) Aluno ${aluno.Nome}, tem ${aluno.Idade} anos, estuda atualmente ${aluno.Inscrito} no ${aluno.Unidade}`) // tipo f-string em python com crase

console.table(aluno)

let nomes = ["Luca", "Evewtich", "Neander", "Guilherme"]



