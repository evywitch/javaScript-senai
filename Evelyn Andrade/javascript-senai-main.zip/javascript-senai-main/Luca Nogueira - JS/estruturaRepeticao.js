// -------- WHILE ---------------
// while tem uma estrutura facil, nao precisa-se explicar aqui, apenas criamos (ou nao) uma variavel para definir a parada da repetição
console.log("--------- WHILE ---------")
contador = 0

while (contador < 10) {
    console.log("OLA")
    contador += 1
}

// ------------ FOR -----------
// Já no for, a estrutura é peculiar, temos que declarar a variavel dentro do for, declarar pulo (se tiver) dentro e, dar a condicao dentro do for, nao precisando de varias linhas para se fazer a mesma coisa comparado com o while. 
console.log ("--------- FOR ---------")

for (let contador = 5; contador < 11; contador++) {
    console.log(contador)
}




