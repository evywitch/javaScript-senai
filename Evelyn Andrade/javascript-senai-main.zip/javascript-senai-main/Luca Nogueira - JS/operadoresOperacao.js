// Operadores de Operação: 

//     - +=
//     - -= 
//     - *=
//     - /= 
    
let valor = 10 

valor += 10 
valor -= 10 
valor *= 3
valor /= 2 

console.log(valor)