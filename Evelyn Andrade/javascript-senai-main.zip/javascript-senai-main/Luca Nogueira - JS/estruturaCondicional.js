let sinal = "Verde"

if (sinal == "Verde") {
    console.log("Passe ")
} else {
    console.log("Pare")
}

// if: se condição for verdadeira, faça 
// else: se a condição for falsa, não faça 
// elif: se a condição do if e else for falso, faça
