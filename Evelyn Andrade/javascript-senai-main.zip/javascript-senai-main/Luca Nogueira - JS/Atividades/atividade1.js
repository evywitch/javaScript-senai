let cores = ["Preto", "Azul", "Vermelho"]

console.log(cores)