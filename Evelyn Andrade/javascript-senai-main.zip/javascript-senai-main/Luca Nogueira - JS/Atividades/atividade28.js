function dobro(num1) {
    console.log(num1 * 2)
}

dobro(2)