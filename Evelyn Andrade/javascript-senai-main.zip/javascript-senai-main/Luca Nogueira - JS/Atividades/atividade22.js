for (let inicio = 0; inicio <= 20; inicio ++) {
    if (inicio %2 == 0) {
        console.log(inicio)
    }
}  

// Use o for para mostrar apenas os números pares de 0 até 20.