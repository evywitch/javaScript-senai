// Crie uma variável idade e mostre quantos anos faltam pra você fazer 100.

let idade = 16
let cem_anos = 100

console.log(`Faltam ${cem_anos - idade} para você completar 100 anos`)