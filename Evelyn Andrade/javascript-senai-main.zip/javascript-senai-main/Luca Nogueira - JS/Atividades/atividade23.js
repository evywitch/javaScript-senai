for (let number = 10; number > 0; number --) {
    console.log(number)
}

// Mostre no console os números de 10 até 1, um por linha.