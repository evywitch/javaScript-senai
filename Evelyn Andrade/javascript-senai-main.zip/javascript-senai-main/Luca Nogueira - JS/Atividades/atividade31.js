let carrinho = ["Abacaxi", "PS5", "GTX 1650"]

carrinho.push("Uva")

console.log(carrinho)