let idade = 15

if (idade >= 16) {
    console.log("Voto obrigatório.")
} else {
    console.log("Não pode votar.")
}