function multiplicar(num1, num2) {
    console.log(num1 * num2)
}

multiplicar(2,7)