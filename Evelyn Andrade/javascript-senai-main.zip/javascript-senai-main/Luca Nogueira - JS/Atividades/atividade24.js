// Crie um for que mostre a tabuada do 5, do 5 x 1 até o 5 x 10.

for (let multiplicador = 0 ;multiplicador <= 10; multiplicador++) {
    console.log(`5 x ${multiplicador} = ${multiplicador * 5}`)
}
