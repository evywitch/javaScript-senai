// Crie uma variável numero e mostre o dobro e a metade desse número.

let numero = 10

console.log(`O dobro de ${numero} é ${numero * 2}`) // dobro 
console.log(`O dobro de ${numero} é ${numero / 2}`) // metade