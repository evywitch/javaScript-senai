// Crie um sinal onde vermelho fique parado e verde passe.

let sinal = "Verde"

if (sinal == "Verde") {
    console.log("Passe")
} else {
    console.log("Pare")
}