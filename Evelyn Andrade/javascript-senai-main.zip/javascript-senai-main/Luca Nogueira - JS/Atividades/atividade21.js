for (let inicio = 0; inicio < 11; inicio ++) {
    console.log(inicio)
}

// Crie um laço for que conte de 1 até 10 e exiba os números no console.