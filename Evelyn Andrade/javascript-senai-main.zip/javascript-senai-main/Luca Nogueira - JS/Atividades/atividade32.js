let nomes = ["Luca", "Evelyn", "Guilherme", "Neander"]

nomes.forEach(function(nomes){
    console.log(`Olá, ${nomes}`)
}) 

