let idade1 = 16
let idade2 = 20 

console.log("---------------------------------------------------------------------------")
console.log(`Idade 1: 16 \n Idade 2: 20 \n Idade 1 é maior que a idade 2? ${idade1 > idade2}`)
console.log("---------------------------------------------------------------------------")
console.log(`Idade 1: 16 \n Idade 2: 20 \n Eles(as) tem a mesma idade? ${idade1 == idade2}`)
console.log("---------------------------------------------------------------------------")
console.log(`Idade 1: 16 \n Idade 2: 20 \n As idade são diferentes? ${idade1 != idade2}`)
console.log("---------------------------------------------------------------------------")

