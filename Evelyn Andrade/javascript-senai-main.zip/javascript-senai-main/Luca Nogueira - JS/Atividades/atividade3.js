// Crie um objeto livro com titulo, autor e paginas. Mostre uma frase com essas informacoes no console. 

let livro = { 
    Titulo: "A paixão segundo g.h",
    Autor: "Clarice Lispector",
    Paginas: 180,
}

console.log(`Titulo do Livro: ${livro.Titulo}\nAutora do Livro: ${livro.Autor}\nPáginas: ${livro.Paginas}`)