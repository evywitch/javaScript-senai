let nota = 4

if (nota == 10) {
    console.log("Excelente.")
} else if (nota >= 7 ) {
    console.log("Bom")
} else if (nota >= 5 ) { 
    console.log("Regular")
} else { 
    console.log("Insuficiente")
}