let mes = 1 

switch (mes) {
    case 1:
        console.log("Janeiro")
        break;

    case 2: 
        console.log("Fevereiro")
        break

    case 3: 
        console.log("Março")
        break

    default:
        console.log("Mês inválido.")
        break;
}