let numeros = [1, 2 , 3]

console.log(numeros[0] + numeros[1])