// While Contar de 50 até 0

contador = 50 

while (contador > 0) {
    console.log(contador)
    contador -= 5
}