let temperatura = 14

if (temperatura >= 15) {
    console.log("Está calor.")
} else {
    console.log("Está frio.")
}