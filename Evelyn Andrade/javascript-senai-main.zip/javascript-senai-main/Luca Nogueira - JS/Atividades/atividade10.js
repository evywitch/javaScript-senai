// Só pode entrar na festa se tiver 18 anos ou mais, expresse ao console a alternativa 

let idade = 18

if (idade >= 18) {
    console.log("Pode entrar na festa.")
} else {
    console.log("Não pode entrar na festa. ")
}