let numero1 = 5
let numero2 = "5"

console.log(numero1 == numero2) // igualdade == , verficar igualdade - True 
console.log(numero1 === numero2) /// 3 iguais comparam o valor e o tipo - False

let x = 5
let y = 7

console.log(x != y) // compara a diferença de algo com outro algo - False 
console.log(x != y) // compara a diferença e tipos de algo com outro algo - True 

console.log(x > y) // False, maior que
console.log(x >= y) // False, maior igual que

console.log(x < y) // True, menor que
console.log(x <= y) // True, menor que




