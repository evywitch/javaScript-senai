// Operadores Aritmeticos 

a = 10 
b = 70

console.log(a + b) // Soma +
console.log(a - b) // Subtração -
console.log(a / b) // Divisão /
console.log(a * b) // Multiplicação *
console.log(a % b) // Resto da divisão % 
console.log(a ** b) // Potenciação **


