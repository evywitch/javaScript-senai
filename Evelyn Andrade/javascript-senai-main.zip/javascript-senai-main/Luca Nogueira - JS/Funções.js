function fazerSuco() {
    console.log("Fazendo suco de laranja...")
}

// -----------------------

// Função com parâmetros: 

function fazerSuco(sabor) {
    console.log(`Fazendo suco de ${sabor}`)
}

// fazerSuco("Uva")

function somar(numero1, numero2) {
    console.log(numero1 + numero2)
}

somar(15,5)
somar(5,1555)
somar(12,3)