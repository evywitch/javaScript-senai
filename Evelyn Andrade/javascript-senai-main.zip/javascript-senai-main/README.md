🇧🇷 - Meu repositório em prol de um curso de JavaSript aprensentado pelo Senai Suiço-Brasileira

🇺🇸 - My repository in favor of a JavaSript course learned by the Swiss-Brazilian Senai

